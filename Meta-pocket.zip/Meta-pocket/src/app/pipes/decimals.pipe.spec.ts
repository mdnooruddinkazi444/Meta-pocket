import { DecimalsPipe } from './decimals.pipe';

describe('DecimalsPipe', () => {
  it('create an instance', () => {
    const pipe = new DecimalsPipe();
    expect(pipe).toBeTruthy();
  });
});
